let projBtn=document.querySelector(".projectBtn");
let projectContainer=document.querySelector(".project-container");
projBtn.addEventListener("click",()=>{
    projectContainer.style.display="block";
})